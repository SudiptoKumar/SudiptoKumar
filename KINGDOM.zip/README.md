<!-- KINGDOM:START (generated: do not edit between these lines) -->
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/hero.svg" width="720" alt="Hero: Sudipto Kumar, level 17 PYTHON ALCHEMIST. Title KINGDOM BUILDER. defending the gate. Quest: hold a 30 day streak."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/world.svg" width="720" alt="The living kingdom. It is dawn, the weather is aurora, the season is autumn. The hero is fighting. 20 repositories stand as buildings, 0 open issues wait as goblins, 0 visitor flags."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/events.svg" width="720" alt="World event: BOSS RAID — SENT BY @SudiptoKumar. Phase: EXPIRED."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/quest.svg" width="720" alt="Kingdom power 72 of 100 (PROSPEROUS KINGDOM). Quests: active hold a 30 day streak, active earn 25 stars, locked hold a 60 day streak."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/districts.svg" width="720" alt="Project districts. Featured: GamingNewsroomBot, TelegramForwarder, BusinessNewsBot, DailyFacts, DocFlow."></p>
<p align="center"><sub><a href="https://github.com/SudiptoKumar/GamingNewsroomBot">GamingNewsroomBot</a> &nbsp;·&nbsp; <a href="https://github.com/SudiptoKumar/TelegramForwarder">TelegramForwarder</a> &nbsp;·&nbsp; <a href="https://github.com/SudiptoKumar/BusinessNewsBot">BusinessNewsBot</a> &nbsp;·&nbsp; <a href="https://github.com/SudiptoKumar/DailyFacts">DailyFacts</a> &nbsp;·&nbsp; <a href="https://github.com/SudiptoKumar/DocFlow">DocFlow</a></sub></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/castle.svg" width="720" alt="The castle: heart of the prosperous kingdom."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/dungeon.svg" width="720" alt="The dungeon beneath the gate: where open issues wait as goblins."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/warfront.svg" width="720" alt="The war front: defenses south of the gate."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/builderyard.svg" width="720" alt="The builder&#39;s yard: where the kingdom grows."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/heroguild.svg" width="720" alt="The hero guild: home base of PYTHON ALCHEMIST."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/trophies.svg" width="720" alt="Trophy hall: 11 of 16 trophies unlocked."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/harvest.svg" width="720" alt="Harvest field: the last 26 weeks of contributions as crops. Streak 16 days."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/history.svg" width="720" alt="Kingdom history: the castle and the settlement over time. Level 17 today."></p>
<p align="center"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/visitors.svg" width="720" alt="Visitor camp: where visitors plant their flags."></p>
<p align="center">
<a href="https://github.com/SudiptoKumar/SudiptoKumar/issues/new?template=plant-your-flag.yml"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/ui/post-flag.svg" width="300" alt="Plant your flag"></a>&nbsp;
<a href="https://github.com/SudiptoKumar/SudiptoKumar/issues/new?template=send-goblin-raid.yml"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/ui/post-raid.svg" width="300" alt="Send a goblin raid"></a>
</p>
<p align="center">
<a href="https://linkedin.com/in/sudipto-kumar"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/ui/guild-linkedin.svg" width="56" alt="LinkedIn"></a>&nbsp;
<a href="https://twitter.com/sudiptokarn"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/ui/guild-x.svg" width="56" alt="X"></a>&nbsp;
<a href="https://instagram.com/real.sudipto"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/ui/guild-instagram.svg" width="56" alt="Instagram"></a>&nbsp;
<a href="https://t.me/NewsroomHQ"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/ui/guild-telegram.svg" width="56" alt="Telegram"></a>&nbsp;
<a href="mailto:sudipto.karn@gmail.com"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/ui/guild-email.svg" width="56" alt="Email"></a>
</p>
<p align="center"><a href="https://github.com/SudiptoKumar/SudiptoKumar/blob/main/KINGDOM.md"><img src="https://raw.githubusercontent.com/SudiptoKumar/SudiptoKumar/main/renderer/status.svg" height="22" alt="Kingdom status"></a></p>
<!-- KINGDOM:END -->
