import json, html, random
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ROOT.mkdir(parents=True, exist_ok=True)

FONT = "ui-monospace,SFMono-Regular,Menlo,Consolas,'Liberation Mono',monospace"
W, H = 1180, 610
CONTENT_X0, CONTENT_X1 = 36, 1144
CONTENT_Y0, CONTENT_Y1 = 84, 576
GAP = 14
LEFT_W = 400
RIGHT_X = CONTENT_X0 + LEFT_W + GAP
RIGHT_W = CONTENT_X1 - RIGHT_X

THEMES = {
    'dark': {
        'outer':'#070B16','panel1':'#0A101F','panel2':'#0C1426','titlebar':'#0B1222',
        'border_soft':'rgba(255,255,255,0.10)','portrait':'#A78BFA','chrome':'#22D3EE','accent':'#10B981',
        'text_primary':'#F8FAFC','text_label':'#94A3B8','text_faint':'#475569','frame_fill':'#0A101F',
        'panel_border':'rgba(34,211,238,0.35)','scan':'#22D3EE','scan2':'#A78BFA'
    },
    'light': {
        'outer':'#E2E5F1','panel1':'#FFFFFF','panel2':'#F4F5FA','titlebar':'#F1F2F8',
        'border_soft':'rgba(15,23,42,0.08)','portrait':'#7C3AED','chrome':'#0891B2','accent':'#059669',
        'text_primary':'#0F172A','text_label':'#475569','text_faint':'#94A3B8','frame_fill':'#FFFFFF',
        'panel_border':'rgba(8,145,178,0.30)','scan':'#0891B2','scan2':'#7C3AED'
    }
}

SECTIONS = [
    ('PROFILE', [('Subject','Sudipto Kumar'),('Role','Full-Stack & Automation Dev'),('Education','BBA · Finance & Banking'),('Status','Building + Automating + Learning')]),
    ('STACK', [('Lang','Python · TS · JS · Kotlin'),('Frontend','React · HTML · CSS'),('Backend','Node.js · .NET'),('Database','Postgres · MySQL · Mongo · Firebase'),('Tooling','Git · Linux · Bash · Postman')]),
    ('CONTACT', [('Mail','sudipto.karn@gmail.com'),('LinkedIn','/in/sudipto-kumar'),('GitHub','@SudiptoKumar'),('Telegram','@NewsroomHQ'),('X','@sudiptokarn'),('Instagram','@real.sudipto')]),
]

def text_w(s, size):
    return len(s) * size * 0.60

def leader(x0,x1,y,color):
    if x1-x0 < 8: return ''
    return f'<line x1="{x0:.1f}" y1="{y}" x2="{x1:.1f}" y2="{y}" stroke="{color}" stroke-width="1" stroke-dasharray="1,3" stroke-linecap="round" opacity="0.5"/>'

def rows_svg(t):
    out=[]
    label_x=RIGHT_X+22; value_x=CONTENT_X1-22; y=CONTENT_Y0+62
    for si,(header,rows) in enumerate(SECTIONS):
        if si: y += 8
        delay = 0.25 + si*0.18
        out.append(f'<g opacity="0"><animate attributeName="opacity" values="0;1" dur="0.45s" begin="{delay:.2f}s" fill="freeze"/>')
        out.append(f'<text x="{label_x}" y="{y}" font-size="13" letter-spacing="2" fill="{t["text_faint"]}">{header}</text>')
        out.append(leader(label_x+text_w(header,13)+10,value_x,y-4,t['border_soft']))
        y += 20
        for ri,(label,value) in enumerate(rows):
            d=delay+0.06*ri
            lw=text_w(label,14); vw=min(text_w(value,14), RIGHT_W-174)
            out.append(f'<text x="{label_x}" y="{y}" font-size="14" fill="{t["text_label"]}">{html.escape(label)}</text>')
            out.append(leader(label_x+lw+10,value_x-vw-10,y-4,t['border_soft']))
            out.append(f'<text x="{value_x}" y="{y}" font-size="14" text-anchor="end" textLength="{vw:.1f}" lengthAdjust="spacingAndGlyphs" fill="{t["text_primary"]}">{html.escape(value)}</text>')
            y += 23
        out.append('</g>')
    return '\n'.join(out)

def path_from_runs(data):
    return ''.join(f'M{x} {y}h{run}v1h-{run}z' for x,y,run in data['runs'])

def fragmented_paths(data, count=64):
    runs=data['runs']
    chunks=[[] for _ in range(count)]
    for i,run in enumerate(runs):
        # distribute by vertical area first, then hashed bucket for more natural fragments
        x,y,n=run
        idx=((y*37 + x*17 + i*13) % count)
        chunks[idx].append(run)
    return [path_from_runs({'runs':c}) for c in chunks if c]

def portrait_svg(theme_name, data, t):
    full=path_from_runs(data)
    chunks=fragmented_paths(data,64)
    grid_w,grid_h=data['grid_w'],data['grid_h']
    pad_top=22; pad_bottom=22
    avail_w=LEFT_W-32; avail_h=(CONTENT_Y1-CONTENT_Y0)-pad_top-pad_bottom
    scale=min(avail_w/grid_w,avail_h/grid_h)
    block_w,block_h=grid_w*scale,grid_h*scale
    tx=CONTENT_X0+(LEFT_W-block_w)/2
    ty=CONTENT_Y0+pad_top+(avail_h-block_h)/2
    s=[]
    s.append(f'<g transform="translate({tx:.1f},{ty:.1f}) scale({scale:.4f},{scale:.4f})" fill="{t["portrait"]}" shape-rendering="crispEdges">')
    # Main portrait: progressive build, then soft pulse, hidden when shatter phase starts.
    s.append('<g>')
    s.append('<animate attributeName="opacity" values="0;1;1" keyTimes="0;0.06;1" dur="3.4s" begin="0s" fill="freeze"/>')
    s.append('<animateTransform attributeName="transform" type="translate" values="0 5;0 0;0 1;0 0" keyTimes="0;0.15;0.55;1" dur="8s" repeatCount="indefinite" calcMode="spline" keySplines="0.2 0 0.2 1;0.4 0 0.6 1;0.4 0 0.6 1"/>')
    s.append(f'<set attributeName="opacity" to="0" begin="3.2s"/>')
    s.append(f'<path d="{full}"/>')
    s.append('</g>')
    # Shatter phase, repeating. Each fragment fades out and returns to its source location.
    s.append('<g opacity="0">')
    s.append('<set attributeName="opacity" to="1" begin="3.2s"/>')
    rng=random.Random(42)
    cycle=13.6
    for i,pd in enumerate(chunks):
        dx=rng.randint(-95,95); dy=rng.randint(-75,75)
        start=3.2 + (i%28)*0.035
        kt='0;0.18;0.34;0.58;0.80;1'
        vals=f'0 0;0 0;{dx} {dy};{dx} {dy};0 0;0 0'
        s.append(f'<g opacity="1">'
                 f'<animate attributeName="opacity" values="1;1;0;0;0;1" keyTimes="{kt}" dur="{cycle}s" begin="{start:.3f}s" repeatCount="indefinite"/>'
                 f'<animateTransform attributeName="transform" type="translate" values="{vals}" keyTimes="{kt}" dur="{cycle}s" begin="{start:.3f}s" repeatCount="indefinite"/>'
                 f'<path d="{pd}"/>'
                 f'</g>')
    s.append('</g>')
    # Scanline/glow that clearly moves during the loop.
    s.append(f'<rect x="-10" y="-10" width="{grid_w+20}" height="12" fill="{t["scan"]}" opacity="0">'
             f'<animate attributeName="y" values="-10;{grid_h+10}" dur="4.6s" begin="1.2s" repeatCount="indefinite"/>'
             f'<animate attributeName="opacity" values="0;0.15;0" dur="4.6s" begin="1.2s" repeatCount="indefinite"/></rect>')
    s.append('</g>')
    return '\n'.join(s)

def build(theme_name):
    t=THEMES[theme_name]
    data=json.load(open(ROOT / f'portrait_{theme_name}_runs.json'))
    rows=rows_svg(t)
    portrait=portrait_svg(theme_name,data,t)
    live_x=CONTENT_X1-22; live_y=CONTENT_Y0+30; pill='@SudiptoKumar'; pill_w=text_w(pill,14)+34
    title='sudipto.karn@gmail.com - % ./profile.sh --live'
    svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="{FONT}" role="img" aria-label="Sudipto Kumar — profile.sh --live">
<defs>
<linearGradient id="accent" x1="0" y1="0" x2="1" y2="0">
<stop offset="0" stop-color="{t['portrait']}"><animate attributeName="stop-color" values="{t['portrait']};{t['chrome']};{t['accent']};{t['portrait']}" dur="10s" repeatCount="indefinite"/></stop>
<stop offset="0.5" stop-color="{t['chrome']}"><animate attributeName="stop-color" values="{t['chrome']};{t['accent']};{t['portrait']};{t['chrome']}" dur="10s" repeatCount="indefinite"/></stop>
<stop offset="1" stop-color="{t['accent']}"><animate attributeName="stop-color" values="{t['accent']};{t['portrait']};{t['chrome']};{t['accent']}" dur="10s" repeatCount="indefinite"/></stop>
</linearGradient>
<linearGradient id="panelGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{t['panel1']}"/><stop offset="1" stop-color="{t['panel2']}"/></linearGradient>
<linearGradient id="scanGrad" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="transparent"/><stop offset="0.5" stop-color="{t['scan2']}"/><stop offset="1" stop-color="transparent"/></linearGradient>
<filter id="glow3" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="3"/></filter>
<clipPath id="winClip"><rect x="2" y="2" width="1176" height="606" rx="18"/></clipPath>
</defs>
<rect x="2" y="2" width="1176" height="606" rx="18" fill="{t['outer']}"/>
<g clip-path="url(#winClip)">
<rect x="2" y="2" width="1176" height="606" fill="url(#panelGrad)"/>
<rect x="2" y="2" width="1176" height="46" fill="{t['titlebar']}"/>
<line x1="2" y1="48" x2="1178" y2="48" stroke="{t['border_soft']}"/>
<circle cx="30" cy="25" r="5.5" fill="#ff5f56"/><circle cx="50" cy="25" r="5.5" fill="#ffbd2e"/><circle cx="70" cy="25" r="5.5" fill="#27c93f"/>
<text x="590" y="29" text-anchor="middle" font-size="12" fill="{t['text_label']}">{html.escape(title)}</text>
<text x="38" y="74" font-size="10" letter-spacing="3" fill="{t['text_faint']}">VISUAL.MAP</text>
<rect x="36" y="84" width="400" height="492" rx="10" fill="none" stroke="{t['chrome']}" stroke-width="2" opacity="0.45" filter="url(#glow3)"/>
<rect x="36" y="84" width="400" height="492" rx="10" fill="{t['frame_fill']}" stroke="{t['panel_border']}"/>
{portrait}
<text x="450" y="74" font-size="10" letter-spacing="3" fill="{t['text_faint']}">SYSTEM.INFO</text>
<rect x="450" y="84" width="694" height="492" rx="10" fill="none" stroke="{t['chrome']}" stroke-width="2" opacity="0.45" filter="url(#glow3)"/>
<rect x="450" y="84" width="694" height="492" rx="10" fill="{t['frame_fill']}" stroke="{t['panel_border']}"/>
<rect x="468" y="100" width="{pill_w:.1f}" height="24" rx="12" fill="rgba(167,139,250,0.12)" stroke="{t['chrome']}" stroke-width="1" opacity="0.8"/>
<text x="{468+pill_w/2:.1f}" y="116" text-anchor="middle" font-size="14" fill="{t['portrait']}">{pill}</text>
<circle cx="1084" cy="114" r="4" fill="#ef4444"><animate attributeName="opacity" values="1;0.2;1" dur="1.4s" repeatCount="indefinite"/></circle>
<text x="1094" y="118" font-size="12" letter-spacing="2" fill="{t['text_label']}">LIVE</text>
{rows}
<rect x="36" y="594" width="1108" height="3" rx="1.5" fill="url(#accent)"/>
<rect x="36" y="592" width="1108" height="1" fill="url(#scanGrad)" opacity="0.7"><animate attributeName="x" values="-1100;1100" dur="7s" repeatCount="indefinite"/></rect>
</g></svg>'''
    return svg

# copy jsons in
import shutil
for theme in ('dark','light'):
    shutil.copy2(Path('/tmp/current')/f'portrait_{theme}_runs.json', ROOT/f'portrait_{theme}_runs.json')
    (ROOT/f'{theme}.svg').write_text(build(theme))
